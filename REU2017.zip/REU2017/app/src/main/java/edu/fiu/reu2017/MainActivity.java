package edu.fiu.reu2017;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;

import static java.lang.String.*;

public class MainActivity extends AppCompatActivity
{
    final static int VECTORSIZE = 10;
    public boolean sendReady= false;
    public Button StartScan;
    public Button TrainData;
    public EditText input;

    TextView output;
    PublicKey pk = new PublicKey();
    PrivateKey sk;
    WiFiDetector RSSSignals;

    //These variables are ONLY for extracting data...
    HashMap<String, Integer> WifiScanResult;
    String [] MACAddressResult;
    Integer [] RSSArrayResult;

    //This is what will be sent to the Server
    ArrayList<Integer> RSSsend = new ArrayList<Integer>();
    ArrayList<String> MACsend = new ArrayList<String>();

    //Unsecure Transmission Variables
    public Button Send;

    //Secure Transmission Variables
    public Button SecureSend;
    SecureTriple secureData;

    //Location
    Double [] coordinates;

    HashMap <String,String> MACAddressUsed = new HashMap<String,String>();

    String [] CommonMAC =
            {
                    "84:1b:5e:4b:80:e2",
                    "84:1b:5e:ca:72:7b",
                    "a0:ec:f9:b2:86:14",
                    "a0:ec:f9:b2:86:10",
                    "a0:ec:f9:9f:8a:04",
                    "a0:ec:f9:11:76:c4",
                    "b4:75:0e:3c:93:86",
                    "3e:3e:84:8c:f8:c5",
                    "60:a4:4c:66:85:ba",
                    "a0:ec:f9:9f:8a:00"
            };

    double x;
    double y;
    String [] loc;
    String incoming;

    //This method is the same as
    //Public Static void main (String [] args)
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);//Must always go first
        setContentView(R.layout.activity_main);//Must always go Second

        //Connect Variables to GUI
        StartScan = (Button) findViewById(R.id.scan);//Connect StartScan to Button in GUI.
        Send = (Button) findViewById(R.id.send);
        SecureSend = (Button) findViewById(R.id.secureSend);
        output = (TextView) findViewById(R.id.output); //Connect to Textbox which outputs...
        TrainData = (Button) findViewById(R.id.train);
        input = (EditText) findViewById(R.id.Insert);

        //Listen for any input, if this button is clicked. Run this method!
        StartScan.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                /*
                    Collect Wi-Fi Data (See WiFi Detector Class)
                 */
                RSSSignals = new WiFiDetector(getApplicationContext());
                WifiScanResult = RSSSignals.getWifiSignalTable();

                /*
                    Need to Prune for ONLY 10 most popular MAC Addresses...
                    Probably best I use ArrayList here??
                 */
                MACAddressResult = WifiScanResult.keySet().toArray(new String[WifiScanResult.size()]);
                RSSArrayResult = WifiScanResult.values().toArray(new Integer[WifiScanResult.size()]);

                /*
                These results were pre-computed...see REUServer Project Build Lookup Table
                For the sake of this Project I was instructed to find the 10 most
                used MAC Addresses and use them for localization.
                 */

                //Ignore this detail...this is how MAC Addresses are mapped to SQL columns
                MACAddressUsed.put("84:1b:5e:4b:80:e2", "ONE");
                MACAddressUsed.put("84:1b:5e:ca:72:7b", "TWO");
                MACAddressUsed.put("a0:ec:f9:b2:86:14", "THREE");
                MACAddressUsed.put("a0:ec:f9:b2:86:10", "FOUR");
                MACAddressUsed.put("a0:ec:f9:9f:8a:04", "FIVE");
                MACAddressUsed.put("a0:ec:f9:11:76:c4", "SIX");
                MACAddressUsed.put("b4:75:0e:3c:93:86", "SEVEN");
                MACAddressUsed.put("3e:3e:84:8c:f8:c5", "EIGHT");
                MACAddressUsed.put("60:a4:4c:66:85:ba", "NINE");
                MACAddressUsed.put("a0:ec:f9:9f:8a:00", "TEN");
                int countvalidAP = 0;

                for (int i =0 ; i< WifiScanResult.size();i++)
                {
                    Log.d("MainLog", "MAC Address Result: " + MACAddressResult[i]);
                    Log.d("MainLog", "RSS Result: " + String.valueOf(RSSArrayResult[i]));
                }

                for(int i = 0;i<VECTORSIZE;i++)
                {
                    if (WifiScanResult.get(CommonMAC[i]) != null)
                    {
                        ++countvalidAP;
                        MACsend.add(CommonMAC[i]);
                        RSSsend.add(RSSArrayResult[i]);
                    }
                    else //AP NOT FOUND!
                    {
                        MACsend.add("NULL");
                        RSSsend.add(-120);
                    }
                }
                output.setText("Valid AP spots detected: " + String.valueOf(countvalidAP));

                for(int j=0;j<VECTORSIZE;j++)
                {
                    Log.d("MainLog", "MAC ADDRESS SENT: " + MACsend.get(j));
                    Log.d("MainLog", "RSS ID SENT:" + RSSsend.get(j));
                }

                sendReady = true;
                output.setText("Scan Completed!");
            }
        });

        TrainData.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                if (sendReady == true)
                {
                    RSSSignals = new WiFiDetector(getApplicationContext());
                    WifiScanResult = RSSSignals.getWifiSignalTable();

                /*
                    Need to Prune for ONLY 10 most popular MAC Addresses...
                    Probably best I use ArrayList here??
                 */
                    MACAddressResult = WifiScanResult.keySet().toArray(new String[WifiScanResult.size()]);
                    RSSArrayResult = WifiScanResult.values().toArray(new Integer[WifiScanResult.size()]);

                    int size = WifiScanResult.size();

                    //Get input x and y coordinates

                    incoming = input.getText().toString();

                    try
                    {
                        Log.d("MainLog","Trying to get Location");
                        loc = incoming.split(",");
                        x = Double.parseDouble(loc[0]);
                        y = Double.parseDouble(loc[1]);
                    }
                    catch(Exception e)
                    {
                        output.setText("INVALID COORDINATES");
                    }

                    Double[] Xlocation = new Double[size];
                    Double[] Ylocation = new Double[size];

                    for (int i = 0; i < size; i++)
                    {
                        Xlocation[i] = x;
                        Ylocation[i] = y;
                    }
                    TrainingArray trainingSend;

                    trainingSend = new TrainingArray(Xlocation, Ylocation, MACAddressResult, RSSArrayResult);

                    for (int i = 0; i < size; i++)
                    {
                        Log.d("MainLog", Xlocation[i] + " " + Ylocation[i]);
                    }

                    //Send it to Database...
                    ClientThread transmitTraining = new ClientThread(trainingSend);
                    new Thread(transmitTraining).start();
                }
                else
                {
                    output.setText("INVALID: PLEASE SCAN FIRST");
                }
            }
        });


        SecureSend.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                if(sendReady == true)
                {
                    BigInteger [] S2 = new BigInteger[VECTORSIZE];
                    BigInteger [] S3 = new BigInteger[VECTORSIZE];
                    //Send Paillier Public Key, Array of MAC Address and unencrypted RSS Values

                    int placeHolder;
                    BigInteger tempS2;

                    for (int i=0;i<VECTORSIZE;i++)
                    {
                        placeHolder = -2 * RSSsend.get(i);
                        tempS2 = Paillier.encrypt(new BigInteger(String.valueOf(placeHolder)), pk);
                        S2 [i] = tempS2;
                        placeHolder = RSSsend.get(i)*RSSsend.get(i);
                        S3 [i] = Paillier.encrypt(new BigInteger(String.valueOf(placeHolder)), pk);
                    }
                    secureData = new SecureTriple(MACsend, S2, S3);
                    ClientThread secureTransmit = new ClientThread(secureData);
                    Thread secureThread = new Thread(secureTransmit);
                    secureThread.start();
                /*
                Wait for Result from the Server, expect to get
                <X-Coordinate, Y-coordinate>
                This will be different from REU 2015 Project because finding minimum distance
                is now done at the server.
                 */
                    coordinates = secureTransmit.getLocation();
                    output.setText("Current Location: " + "X: " + String.valueOf(coordinates[0])+
                            " Y: " + String.valueOf(coordinates[1]));
                }
                else
                {
                    output.setText("INVALID: PLEASE SCAN FIRST");
                }
            }
       });

        Send.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                if(sendReady==true)
                {
                    //Send Paillier Public Key and Send  MAC Address, S2, S3, stored in ArrayList transmit...
                    ClientThread secretSend = new ClientThread(new UnsecureTriple(MACsend, RSSsend));
                    Thread PlainT = new Thread (secretSend);
                    PlainT.start();

                    /*
                    Wait for Result from the Server, expect to get
                    <X-Coordinate, Y-coordinate>
                    This will be different from REU 2015 Project because finding minimum distance
                    is now done at the server.
                    */

                    //PROBLEM COORDINATES ARE STILL NULL
                    while (secretSend.getLocation()==null)
                    {
                        coordinates = secretSend.getLocation();
                    }
                    /*
                     */
                    output.setText("Current Location: " + "X: " + String.valueOf(coordinates[0])+
                            " Y: " + String.valueOf(coordinates[1]));
                }
                else //Test out socket
                {
                    output.setText("INVALID: PLEASE SCAN FIRST");
                }
            }
        });

    }
}
