package edu.fiu.reu2017;

/**
 * Created by Andrew on 6/27/2017.
 */

import android.util.Log;

import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintStream;
import java.math.BigInteger;
import java.net.Inet4Address;
import java.net.MalformedURLException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Scanner;

public class ClientThread extends Thread
{
    /*
    MAC 1: 84:1b:5e:4b:80:e2
    MAC 2: 84:1b:5e:ca:72:7b
    MAC 3: a0:ec:f9:b2:86:14
    MAC 4: a0:ec:f9:b2:86:10
    MAC 5: a0:ec:f9:9f:8a:04
    MAC 6: a0:ec:f9:11:76:c4
    MAC 7: b4:75:0e:3c:93:86
    MAC 8: 3e:3e:84:8c:f8:c5
    MAC 9: 60:a4:4c:66:85:ba
    MAC 10: a0:ec:f9:9f:8a:00
     */
    final static String SQLDatabase = "10.102.206.176";
    //final static String SQLDatabase = "10.110.43.222";
    final static int portNumber = 9254;

    //ServerSocket SQLServerSocket;
    Socket ClientSocket;

    String x; //input
    String answer; //output
    PublicKey pk;//Paillier Public Key
    SecureTriple secureTransmission; //For Encrypted Paillier Transmission

    UnsecureTriple insecureTransmission;
    public boolean isSecure=true;
    Double [] location;
    public boolean training;
    TrainingArray sendTraining;

    public ClientThread(String number)
    {
        x=number;
    }


    public ClientThread (SecureTriple input)
    {
        secureTransmission = input;
        isSecure = true;
        training = false;
    }

    public ClientThread (UnsecureTriple in)
    {
        insecureTransmission = in;
        isSecure=false;
        training = false;
    }

    public ClientThread (TrainingArray in)
    {
        sendTraining = in;
        training = true;
    }

    public Double [] getLocation () {return location;}

    public String getAnswer() {return answer;}

    void closeConnection()
    {
        try
        {
            //SQLServerSocket.close();//kill server socket
            if(ClientSocket != null)
            {
                if (ClientSocket.isConnected())
                {
                    ClientSocket.close();
                }
            }
        }
        catch(IOException ioe)
        {
            Log.d("ClientSocket", "Void Close Failure "+ ioe.getMessage());
            ioe.printStackTrace();
        }
        Log.d("ClientSocket", "Sucessfully closed sockets");
    }

    public void run ()
    {
        /*
         Add: <uses-permission android:name="android.permission.INTERNET"/>
         to AndroidManifest.xml if I get "socket failed:EACCES(Permission denied)
         */
        /*
        Note to self this probably isn't working from University Towers because the VM
        is not near EC from University Towers?? Confirm with Akkaya...Could be important to mention!
         */

        try
        {
            Log.d("ClientSocket", "RUN METHOD STARTED");
            //Secure Transmission
            if(isSecure==true && training == false)
            {
                Log.d("ClientSocket", "STARTING IS SECURE TRANSMISSION");
                //Build the Socket
                ClientSocket = new Socket(SQLDatabase, portNumber);
                Log.d("ClientSocket", "Client Socket Successfuly Built" + portNumber);

                //Troubleshoot/Confirm the Socket Sucessfully connected
                if (!ClientSocket.isConnected())
                {
                    Log.d("ClientSocket", "Client Socket is NOT connected" + portNumber);
                }
                Log.d("ClientSocket", "Client Socket Successfuly Connected" + portNumber);

                //Prepare to send objects
                ObjectOutputStream outToServer = new ObjectOutputStream(ClientSocket.getOutputStream());
                Log.d("ClientSocket", "Finished Creating OutputStream");
                outToServer.writeObject(sendTraining);
                Log.d("ClientSocket", "Finished Writing to OutputStream");
                //Wait to get confirmation that the data sucessfully inserted...
                ObjectInputStream fromServer = new ObjectInputStream(ClientSocket.getInputStream());
                Log.d("ClientSocket", "Finished Openined Object Input Stream");
                //Send Paillier Public Key
                //outToServer.writeObject(pk);

                //Send the Secure Object
                outToServer.writeObject(secureTransmission);

                try
                {
                    this.sleep(20*1000);//Sleep for 20 seconds...
                }
                catch (InterruptedException IE)
                {
                    IE.printStackTrace();
                }

                //Get Input from Server
                location = (Double [])fromServer.readObject();
                Log.d("My Log", "Data just arrived from server " + portNumber);
            }
            //Unsecure Transmission
            else if(isSecure == false && training == false)
            {
                Log.d("ClientSocket", "STARTING INSECURE TRANSMISSION");
                //Build the Socket
                /*
                Current Issue: TIMED OUT
                Looks like I need to move to VM again...
                NOTE: ADDING PORT 9254 exception to firewall did NOT work!
                 */
                ClientSocket = new Socket(SQLDatabase, portNumber);
                Log.d("ClientSocket", "Client Socket Successfuly Built" + portNumber);

                //Troubleshoot/Confirm the Socket Sucessfully connected
                if (!ClientSocket.isConnected())
                {
                    Log.d("ClientSocket", "Client Socket is NOT connected" + portNumber);
                }
                Log.d("ClientSocket", "Client Socket Successfuly Connected" + portNumber);

                //Prepare to send Objects
                ObjectOutputStream outToServer = new ObjectOutputStream(ClientSocket.getOutputStream());
                Log.d("ClientSocket", "Finished Creating OutputStream");
                outToServer.writeObject(insecureTransmission);
                Log.d("ClientSocket", "Finished Writing to OutputStream");
                //Wait to get confirmation that the data sucessfully inserted...
                ObjectInputStream fromServer = new ObjectInputStream(ClientSocket.getInputStream());
                Log.d("ClientSocket", "Finished Openined Object Input Stream");

//                try
//                {
//                    this.sleep(10*1000);//Sleep for 20 seconds...
//                }
//                catch (InterruptedException IE)
//                {
//                    IE.printStackTrace();
//                }

                //Wait for Server, I should expect a double array containing x and y...
                location = (Double [])fromServer.readObject();
                Log.d("My Log", "Data just arrived from server " + portNumber);
            }
            else if(training == true)
            {
                Log.d("ClientSocket", "STARTING TESTING SOCKET");
                ClientSocket = new Socket(SQLDatabase, portNumber);
                Log.d("ClientSocket", "Client Socket Successfuly Built" + portNumber);

                //Troubleshoot/Confirm the Socket Sucessfully connected
                if (!ClientSocket.isConnected())
                {
                    Log.d("ClientSocket", "Client Socket is NOT connected" + portNumber);
                }
                Log.d("ClientSocket", "Client Socket Successfully Connected" + portNumber);

                ObjectOutputStream outToServer = new ObjectOutputStream(ClientSocket.getOutputStream());
                //Send the Training Data
                Log.d("ClientSocket", "Finished Creating OutputStream");
                Log.d("ClientSocket", "Class Name of Object being sent is: " + sendTraining.getClass());

                outToServer.writeObject(sendTraining);
                Log.d("ClientSocket", "Finished Writing to OutputStream");
                //Wait to get confirmation that the data sucessfully inserted...
                ObjectInputStream fromServer = new ObjectInputStream(ClientSocket.getInputStream());
                Log.d("ClientSocket", "Finished Opening Object Input Stream");

                //Wait a bit for Server to Respond...
//                try
//                {
//                    this.sleep(10*1000);//Sleep for 20 seconds...
//                }
//                catch (InterruptedException IE)
//                {
//                    IE.printStackTrace();
//                }
                boolean dataInserted=false;
                try
                {
                    dataInserted = fromServer.readBoolean();
                }
                catch(EOFException eof)
                {
                    if (dataInserted==true)
                    {
                        Log.d("ClientSocket", "Data Inserted");
                    }
                    else
                    {
                        Log.d("ClientSocket", "Data NOT inserted");
                    }
                }
           /*     Log.d("ClientSocket", "STARTING TESTING SOCKET");
                //Build the Socket
                int num = Integer.parseInt(x);//Just for Testing purposes

                ClientSocket = new Socket(SQLDatabase, portNumber);
                Log.d("ClientSocket", "Client Socket Successfuly Built" + portNumber);

                //Troubleshoot/Confirm the Socket Sucessfully connected
                if (!ClientSocket.isConnected())
                {
                    Log.d("ClientSocket", "Client Socket is NOT connected" + portNumber);
                }
                Log.d("ClientSocket", "Client Socket Successfully Connected" + portNumber);
                Log.d("ClientSocket", "Input from Client: " + num);

                PrintStream p = new PrintStream(ClientSocket.getOutputStream());//Testing
                p.println(num);//Send Number x, Just for Testing...

                Scanner serverResponse = new Scanner(ClientSocket.getInputStream());
                int temp = serverResponse.nextInt();//Testing Purposes....
                Log.d("ClientSocket", "Data just arrived from server " + portNumber);

                answer = String.valueOf(temp);
                Log.d("ClientSocket", "answer is " + answer);*/
            }

            //Close Everything
            this.closeConnection();
        }
        catch (UnknownHostException uhe)
        {
            Log.d("Client", "CLIENT THREAD FAILURE: UNKNOWN HOST EXCEPTION");
            uhe.printStackTrace();
        }
        //Currently my connection is timing out...
        catch (IOException ioe)
        {
            Log.d("Client", "CLIENT THREAD FAILURE: I/O Exception, " +
                    "CHECK IF YOU ARE CONNECTED TO WI-FI, FIREWALL, AND HAVE RIGHT IP ADDRESS!!!");
            ioe.printStackTrace();
            //This can be caused if the phone is too far from 3rd floor of EC.
        }
        catch (ClassNotFoundException cnf)
        {
            Log.d("Client", "CLIENT THREAD FAILURE: CLASS NOT FOUND");
            cnf.printStackTrace();
        }
        //If you have a Timed out connection...You probably are NOT connected to the Internet...
    }
}
