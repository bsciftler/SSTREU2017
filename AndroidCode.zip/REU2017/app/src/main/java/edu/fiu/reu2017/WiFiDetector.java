package edu.fiu.reu2017;

import android.content.Context;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.net.wifi.ScanResult;
import android.util.Log;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.HashMap;
import java.util.List;

/**
 * Created by Andrew on 6/26/2017.
 */

public class WiFiDetector
{
    private WifiManager mWifiManager;
    private ScanResult REUScan;
    HashMap<String, Integer> WifiDataPoints = new HashMap<String,Integer>();
    final boolean sucessfulScan;
    List<ScanResult> results;

    public WiFiDetector(Context context)
    {
        mWifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
        sucessfulScan = mWifiManager.startScan();
        results = mWifiManager.getScanResults();
        this.wifiScan();
    }

    /*
        Method: Collect Wi-Fi
     */
    public void wifiScan ()
    {
        Log.d("Scan", "Intiialized WifiScan Method");
        String s = results.get(0).BSSID + " " + results.get(0).level;

        int temp;
        String MAC;

        MAC = results.get(0).BSSID;
        temp = results.get(0).level;
        Log.d("Scan", MAC);
        Log.d("Scan", String.valueOf(temp));

        int counter = results.size() - 1;
        /* Print out to WifiOUT */

        Log.d("Scan", "Begin While Loop and counter is at: " + counter);
        while (counter >= 0)
        {
            MAC = results.get(counter).BSSID;
            temp = results.get(counter).level;
            Log.d("Scan", MAC);
            Log.d("Scan", String.valueOf(temp));
            WifiDataPoints.put(MAC, temp);
            --counter;
        }
    }

    /*
        Keep MAC Address Data unecrntyped,
        Encrypt the RSS signals using Paillier
     */

    public HashMap<String, Integer> getWifiSignalTable()
    {
        return WifiDataPoints;
    }
}
