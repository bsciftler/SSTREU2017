package edu.fiu.reu2017;

import java.io.Serializable;

/**
 * Created by Andrew on 7/6/2017.
 */

public class TrainingArray implements Serializable
{
    private final Double [] Xcoordinate;
    private final Double [] Ycooridnate;
    private final String [] MACAddress;
    private final Integer [] RSS;

    public TrainingArray(Double [] x, Double [] y, String [] m, Integer [] in)
    {
        Xcoordinate = x;
        Ycooridnate = y;
        MACAddress = m;
        RSS = in;
    }

    public Double [] getX () {return Xcoordinate;}
    public Double [] getY () {return Ycooridnate;}
    public String [] getMACAddress () {return MACAddress;}
    public Integer [] getRSS () {return RSS;}
}
